const text = document.querySelector(".sec-text");
    const textLoad = () => {
        setTimeout(() => {
            text.textContent = "prince babariya";
        }, 0);
        setTimeout(() => {
            text.textContent = "Developer";
        }, 4000);
        setTimeout(() => {
            text.textContent = "Designer";
        }, 8000);
    }
    
    textLoad();
    setInterval(textLoad, 12000);